public class hewan {
    String Nama, Jenis, Suara;

    void tampilkanInfo(){
        System.out.println("Nama : "+Nama);
        System.out.println("Jenis : "+Jenis);
        System.out.println("Suara : "+Suara);
        System.out.println("");
    }
}
