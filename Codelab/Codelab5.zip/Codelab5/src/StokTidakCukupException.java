public class StokTidakCukupException extends RuntimeException {
    public StokTidakCukupException(String message) {
        super(message);
    }
}
